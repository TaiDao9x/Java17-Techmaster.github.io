# Nghị định 469/NQ-UBTVQH15
Nghị quyết về việc thành lập các phường thuộc thị xã Phổ Yên và thành lập thành phố Phổ Yên, tỉnh Thái Nguyên.  
Thành lập 09 phường thuộc thị xã Phổ Yên và thành lập thành phố Phổ Yên, tỉnh Thái Nguyên.  
**Ngày ban hành**: 15/02/2022  
**Ngày có hiệu lực**: 10/04/2022  
Chi tiết xem tại: [469/NQ-UBTVQH15](https://luatvietnam.vn/dia-gioi-hanh-chinh/nghi-quyet-469-nq-ubtvqh15-uy-ban-thuong-vu-quoc-hoi-217275-d1.html)

## Nội dung bản cập nhật

- Cập nhật Phổ Yên (172) từ cấp Thị xã (6) thành cấp Thành phố thuộc tỉnh (4)
- Cập nhật Hồng Tiến, Đắc Sơn, Tiên Phong, Nam Tiến, Tân Hương, Đông Cao, Trung Thành, Tân Phú, Thuận Thành 
từ cấp Xã (10) lên Phường (8)

### Hướng dẫn cập nhật
Cập nhật bằng cách chạy trực tiếp tệp patch [469_NQ-UBTVQH15_patch.sql](469_NQ-UBTVQH15_patch.sql)

---
_English_  

Decree 469/NQ-UBTVQH15  
- Change Phổ Yên (172) from District-level town (Thị xã - 6) to provincial city (Thành phố thuộc tỉnh - 4)  
- Change Hồng Tiến, Đắc Sơn, Tiên Phong, Nam Tiến, Tân Hương, Đông Cao, Trung Thành, Tân Phú, Thuận Thành from commune (Xã - 10) to ward (Phường - 8)  

How to run: Execute the patch [469_NQ-UBTVQH15_patch.sql](469_NQ-UBTVQH15_patch.sql) directly   
