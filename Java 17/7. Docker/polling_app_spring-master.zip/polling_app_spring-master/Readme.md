Sample Dockerize Java Spring + Reactjs + MySQL
